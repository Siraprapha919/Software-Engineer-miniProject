<?php
    try {
        ob_start();
    
?>
<html>
<script>
        function checkEmpty(){
            var use = document.getElementById("username");
            var pas = document.getElementById("password");
            if(use.value == ""){
                alert("Please Enter Your Username!!!");
                use.focus();
            }
            else if(pas.value == ""){
                alert("Please Enter Your Password!!!");
                pas.focus();
            }
            else if(use.value == "" || pas.value == ""){
                alert("Please Enter Your Username and Password");
                use.focus();
                pas.focus();
            }
            else{
                document.getElementById("loginForm").onsubmit;
            }

        }

        function textSelect(elem){
            elem.select();
        }
    </script>
    <div class="message-box text-center section lb">
    <form name="signUp" id="signUp" method="post" 
        action=<?= Router::getSourcePath() . "index.php?controller=Member&action=signUp" ?>>
        <label class="text-dark" align="right" style="width: 80%; margin:auto">สมัครสมาชิก&nbsp&nbsp</label>
        <button class="btn btn-secondary text-center" type="submit">Sign Up</button>
        <br>                       
        <h2>Login</h2>
    </form>
    <br>
    <div style="width: 50%; margin:auto">
		<div class="section db">
        <div class="text-white" align="center">
            <?= $_GET['msg'] ?? "" ?>
        </div>
            <form name="loginForm" id="loginForm" method="post" 
            action=<?= Router::getSourcePath() . "index.php?controller=Member&action=login" ?>>
                <br>
                <h3 style="color: white;" align="left">Username:&nbsp&nbsp</h3>
                <input class="form-control" type="text" 
                name="username" id="username" placeholder="Username" onfocus="textSelect(this)" required/>
                <br>
                <h3 style="color: white;" align="left">Password:&nbsp&nbsp</h3>
                <input class="form-control" type="password" 
                name="password" id="password" placeholder="Password" onfocus="textSelect(this)" required/>
                <br>
                <button class="btn btn-success" type="submit" onclick="checkEmpty();">Login</button>
                <button class="btn btn-danger" type="reset">Cancel</button>
            </form>
	    </div>
    </div>
    </div>
</html>
<?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
    ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
    echo "Access denied: No Permission to view this page";
    exit(1);
}
?>