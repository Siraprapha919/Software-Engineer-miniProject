<?php
    try {
        ob_start();
    
?>
<body>
<script>
function myFunction() {
    if (confirm("Are you want to confirm sign up?") == true) {
        document.getElementById("signUpForm").submit();
    } 
}
</script>
<div class="message-box text-center section lb">
<div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post" 
        action=<?= Router::getSourcePath() . "index.php"?>>
            <button class="btn btn-secondary text-center" type="submit">Back</button>
            <br>
    </form>
    </div>
    <h2>Sign Up</h2>
    <br>
    <div class="section db" style="width: 50%; margin:auto">
        <div class="sign-up-form">
            <form name="signUpForm" id="signUpForm" method="post" 
            action=<?= Router::getSourcePath() . "index.php?controller=Member&action=addNew"?>>
                <h3 style="color: white;" align="left">Name:</h3>
                <input class="form-control" type="text" name="name" placeholder="Name" 
                required/>
                <br>
                <h3 style="color: white;" align="left">Surname:</h3>
                <input class="form-control" type="text" name="surname" placeholder="Surname" 
                required/>
                <br>
                <h3 style="color: white;" align="left">Username:</h3>
                <input class="form-control" type="text" name="username" placeholder="Username" 
                required/>
                <br>
                <h3 style="color: white;" align="left">Password:</h3>
                <input class="form-control" type="text" name="password" placeholder="Password" 
                required/>
                <br>
                <h3  style="color: white;" align="left">Occupation:</h3>
                <select id="role" name="role" style="width: 100%; margin:auto" class="btn btn-white dropdown-toggle alignleft" required/>
                <option value="" selected>อาชีพ</option>
                <option value="นิสิต">นิสิต</option>
                <option value="อาจารย์">อาจารย์</option>
                <option value="เจ้าหน้าที่">เจ้าหน้าที่</option>
                </select><br/><br/>
                <h3 style="color: white;" align="left">Adviser ID:</h3>
                <input class="form-control" type="text" name="idAdviser" placeholder="Adviser ID"
                       required/>
                <br><br>
                <button class="btn btn-success" type="button" onclick="myFunction();">SignUp</button>
                <button class="btn btn-danger" type="reset">Cancel</button>
                <br>
			</form>
	    </div>
    </div>
</div>
<?php

$content = ob_get_clean();

include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
echo "Access denied: No Permission to view this page";
exit(1);
}
?>