<?php
try {
    ob_start();

    ?>
    <body>
<div class="message-box text-center section lb">
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "index.php?controller=Member&action=edit" ?>>
            <button class="btn btn-secondary text-center" type="submit">Back</button>
            <br>
        </form>
    </div>
    <h2>Edit Equipment</h2>
    <br>
    <div class="section db" style="width: 50%; margin:auto">
        <div class="sign-up-form">
            <form name="signUpForm" id="signUpForm" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Member&action=changeMe"?>>
                <?php
                $equip = Member::findById($_GET["id"]);
                ?>
                <h3 style="color: white;" align="left">Id:</h3>
                <input class="form-control" type="text" name="id" value=<?php echo $equip->getIdUser();?> required/>
                <br>
                <h3 style="color: white;" align="left">Name:</h3>
                <input class="form-control" type="text" name="name" value=<?php echo $equip->getName();?> required/>
                <br>
                <h3 style="color: white;" align="left">Surname:</h3>
                <input class="form-control" type="text" name="surname" value=<?php echo $equip->getSurname();?> required/>
                <br>
                <h3 style="color: white;" align="left">Username:</h3>
                <input class="form-control" type="text" name="username" value=<?php echo $equip->getUsername();?> required/>
                <br>
                <h3 style="color: white;" align="left">Password:</h3>
                <input class="form-control" type="text" name="password" value=<?php echo $equip->getPassword();?> required/>
                <br>
                <h3 style="color: white;" align="left">Role:</h3>
                <select name="role" style="width: 100%; margin:auto" class="btn btn-white dropdown-toggle alignleft" required/>
                <?php
                foreach ($role = Member::findRole() as $row) {
                    foreach ($row as $col) {
                        echo "<option value=" . "'" . $col . "'>" . $col . "</option>";
                    }
                }
                ?>
                </select><br/><br/><br/>
                <h3  style="color: white;" align="left">Adviser ID:</h3>
                <input class="form-control" type="text" name="idadviser" value=<?php echo $equip->getIdAdviser();?> required/>
                <br>
                <button class="btn btn-success" type="submit">Save</button>
                <button class="btn btn-danger" type="reset">Cancel</button>
                <br>
            </form>
        </div>
    </div>
</div>
    <?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
    ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
    echo "Access denied: No Permission to view this page";
    exit(1);
}
?>