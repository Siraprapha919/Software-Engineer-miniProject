<?php
try {
ob_start();
?>
<div class="message-box text-center section lb">
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "logout.php"?>>
            <button class="btn btn-secondary text-center" type="submit">Logout</button>
            <br>
        </form>
    </div>
    <h2>รายการอุปกรณ์</h2>
    <br>
    <div>
        <div class="navbar-nav">
            <ul class="nav nav-tabs aligncenter" role="tablist" style="width: 100%; margin:auto">
                <a href="index.php?controller=Member&action=backhome" class="btn btn-dark text-center">อุปกรณ์</a>
                <a href="index.php?controller=Member&action=profile" class="btn btn-dark text-center">ข้อมูลส่วนตัว</a>
                <a href="index.php?controller=Borrow&action=news" class="btn btn-dark text-center">ประวัติการยืม-คืน</a>
            </ul>
        </div>
    </div>
    <br/>
    <div class="section-block signup" style="width: 50%; margin:auto">
        <div align="center" style="width: 60%; margin:auto">
            <?php
            session_start();
            $name = $_SESSION['name'] ;
            $surname = $_SESSION['surname'];
            $username = $_SESSION['username'];
            $password = $_SESSION['password'] ;
            $role = $_SESSION['role'];
            $idAdviser = $_SESSION['idAdviser'] ;

            echo "<h4 style='color: black;'>Name:&nbsp".$name."</h4><br>";
            echo "<h4 style='color: black;'>Surname:&nbsp".$surname."</h4><br>";
            echo "<h4 style='color: black;'>Username:&nbsp".$username."</h4><br>";
            echo "<h4 style='color: black;'>Role:&nbsp".$role."</h4><br>";
            echo "<h4 style='color: black;'>IdAdviser:&nbsp".$idAdviser."</h4><br>";

            ?>
        </div>
    </div>
    <?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
    } // -- try
    catch (Throwable $e) {
        ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
        echo "Access denied: No Permission to view this page";
        exit(1);
    }
    ?>
