<?php
try {
    ob_start();
    session_start();
    ?>
    <div class="message-box text-center section lb">
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "logout.php"?>>
            <button class="btn btn-secondary text-center" type="submit">Logout</button>
            <br>
        </form>
    </div>
    <?php
    //No admin
    ?>
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "index.php?controller=Borrow&action=borrow"?>>
            <button class="btn btn-secondary text-center" type="submit">BorrowEquipment</button>
            <br>
        </form>
    </div>
    <?php
        //admin
    if($_SESSION['role'] == "เจ้าหน้าที่" ) {
        ?>
        <div align="right" style="width: 80%; margin:auto">
            <form name="back" id="back" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Equipment&action=edit" ?>>
                <button class="btn btn-secondary text-center" type="submit">EditEquipment</button>
                <br>
            </form>
        </div>
        <div align="right" style="width: 80%; margin:auto">
            <form name="back" id="back" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Type&action=edit" ?>>
                <button class="btn btn-secondary text-center" type="submit">EditTypeOfEquipment</button>
                <br>
            </form>
        </div>
        <div align="right" style="width: 80%; margin:auto">
            <form name="back" id="back" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Member&action=edit" ?>>
                <button class="btn btn-secondary text-center" type="submit">EditMember</button>
                <br>
            </form>
        </div>
        <?php
    }
     ?>

    <h2>รายการอุปกรณ์</h2>
    <br>
    <div>
        <div class="navbar-nav">
            <ul class="nav nav-tabs aligncenter" role="tablist" style="width: 100%; margin:auto">
                <a href="index.php?controller=Member&action=backhome" class="btn btn-dark text-center">อุปกรณ์</a>
                <a href="index.php?controller=Member&action=profile" class="btn btn-dark text-center">ข้อมูลส่วนตัว</a>
                <a href="index.php?controller=Borrow&action=news" class="btn btn-dark text-center">ประวัติการยืม-คืน</a>
                <br/><br/>
                <label class="btn btn-dark text-center" style="margin: auto">Equipment Type</label>
            </ul>
            <form method="post" action=<?= Router::getSourcePath() . "index.php?controller=Member&action=index"?>>
                <select name="typename" style="width:30%; margin:auto; text-align: center" class="btn btn-white dropdown-toggle" required/>
                <option >  </option>
            <?php
                $row = Type::findAll();
                foreach ($row as $r){
                    echo "<option  value=" . "'" . $r->getIdType() . "'>" . $r->getName() . "</option>";
                }
            ?>
            </select><br/>
                <button type="submit" class="btn btn-dark text-center">Search</button>
            </form>
        </div>
    </div>
    <br/>
    <div class="section wb" style='width: 75%; margin:auto'>
        <?php
        $header = array("Equipment ID","Name","Status");
        if(isset($_POST['typename'])) {
            $equip = Equipment::findByType($_POST['typename']);
        }else{
            $equip = Equipment::findAllEquip();
        }
        echo "<table class='table text-center bg-dark' style='width: 100%; margin:auto'>";
        echo"<thead>";
        echo "<tr>";
        foreach ($header as $h){
            echo "<th class='text-center'>$h</th>";
        }
        echo "</tr>";
        echo"</thead>";
        echo"<tbody>";

        foreach ($equip as $row) {
            echo "<tr>";
            foreach ($row as $col){
                echo "<td>".$col."</td>";

            }
            /*echo "<td><a href=index.php?controller=Reserve&action=change&id=".$row["reserveID"]."
            class='btn btn-info text-center'>รายละเอียด</a></td>";*/
            echo "</tr>";

        }
        echo "</tbody>";
        echo "</table>";
        ?>
    </div>
    <?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
    ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
    echo "Access denied: No Permission to view this page";
    exit(1);
}
?>