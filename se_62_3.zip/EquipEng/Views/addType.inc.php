<?php
try {
    ob_start();

    ?>
    <body>
<div class="message-box text-center section lb">
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "index.php?controller=Type&action=edit" ?>>
            <button class="btn btn-secondary text-center" type="submit">Back</button>
            <br>
        </form>
    </div>
    <h2>Add Type Of Equipment</h2>
    <br>
    <div class="section db" style="width: 50%; margin:auto">
        <div class="sign-up-form">
            <form name="signUpForm" id="signUpForm" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Type&action=addType"?>>
                <h3 style="color: white;" align="left">Name:</h3>
                <input class="form-control" type="text" name="name" required/>

                <br><br>
                <button class="btn btn-success" type="submit">Save</button>
                <button class="btn btn-danger" type="reset">Cancel</button>
                <br>
            </form>
        </div>
    </div>
</div>
    <?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
    ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
    echo "Access denied: No Permission to view this page";
    exit(1);
}
?>