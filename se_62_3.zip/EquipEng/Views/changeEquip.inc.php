<?php
try {
    ob_start();

    ?>
    <body>
<div class="message-box text-center section lb">
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "index.php?controller=Equipment&action=edit" ?>>
            <button class="btn btn-secondary text-center" type="submit">Back</button>
            <br>
        </form>
    </div>
    <h2>Edit Equipment</h2>
    <br>
    <div class="section db" style="width: 50%; margin:auto">
        <div class="sign-up-form">
            <form name="signUpForm" id="signUpForm" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Equipment&action=changeEq"?>>
                <?php
                $equip = Equipment::findById($_GET["id"]);
                ?>
                <h3 style="color: white;" align="left">Name:</h3>
                <input class="form-control" type="text" name="id" value=<?php echo $equip->getIdEquipment();?> required/>
                <br>
                <h3 style="color: white;" align="left">Name:</h3>
                <input class="form-control" type="text" name="name" value=<?php echo $equip->getName();?> required/>
                <br>
                <h3  style="color: white;" align="left">Type:</h3>
                <select name="type" style="width: 100%; margin:auto" class="btn btn-white dropdown-toggle alignleft" required/>
                <?php
                $row = Type::findAll();
                for ($i = 1;$i <= count($row) ;$i++)
                    echo "<option value="."'".$row[$i]->getIdType()."'>".$row[$i]->getName()."</option>";
                ?>
                </select><br/><br/>
                <h3 style="color: white;" align="left">Status:</h3>
                <input class="form-control" type="text" name="stat" value=<?php echo $equip->getStatus();?> required/>
                <br><br>
                <button class="btn btn-success" type="submit">Save</button>
                <button class="btn btn-danger" type="reset">Cancel</button>
                <br>
            </form>
        </div>
    </div>
</div>
    <?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
    ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
    echo "Access denied: No Permission to view this page";
    exit(1);
}
?>