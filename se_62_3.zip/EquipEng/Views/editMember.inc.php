<?php
try {
    ob_start();

    ?>
    <body>
<div class="message-box text-center section lb">
    <div align="right" style="width: 80%; margin:auto">
        <form name="back" id="back" method="post"
              action=<?= Router::getSourcePath() . "index.php?controller=Member&action=index" ?>>
            <button class="btn btn-secondary text-center" type="submit">Back</button>
            <br>
        </form>
    </div>
    <h2>Edit Equipment</h2>
    <br>
    <div class="section db" style="width: 80%; margin:auto">
        <div class="sign-up-form">
            <form name="signUpForm" id="signUpForm" method="post"
                  action=<?= Router::getSourcePath() . "index.php?controller=Member&action=index"?>>
                <?php
                $header = array("User ID","Name","Surname","Username","Password","Role","Adviser ID","Edit");
                echo "<table class='table text-center bg-dark' style='width: 100%; margin:auto'>";
                echo"<thead>";
                echo "<tr>";
                foreach ($header as $h){
                    echo "<th class='text-center'>$h</th>";
                }
                echo "</tr>";
                echo"</thead>";
                echo"<tbody>";

                foreach ($equip = Member::findAll() as $row) {
                    echo "<tr>";
                    foreach ($row as $col){
                        echo "<td>".$col."</td>";

                    }
                    echo "<td>
                        <a href=index.php?controller=Member&action=delete&id=".$row["idUser"]."
                    class='btn btn-info text-center bg-danger'>Delete</a>
                        <a href=index.php?controller=Member&action=change&id=".$row["idUser"]."
                    class='btn btn-info text-center bg-danger'>Edit</a></td>";
                    echo "</tr>";

                }
                echo "</tbody>";
                echo "</table>";
                ?>
                <br/>
                <button class="btn btn-success" type="submit">Save</button>
                <br>
            </form>
        </div>
    </div>
</div>
    <?php

    $content = ob_get_clean();

    include Router::getSourcePath()."layout.php";
} // -- try
catch (Throwable $e) {
    ob_clean(); // ล้าง output เดิมที่ค้างอยู่จากการสร้าง page
    echo "Access denied: No Permission to view this page";
    exit(1);
}
?>