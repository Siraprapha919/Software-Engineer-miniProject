<header>
<br>
	<div class="container">
    <img class="alignleft" src="Image/26166724_1201693619964370_5174147735145290156_n.jpg" width="90" height="87">
    <br>
    <h1><font color="#ffffff"><b>ระบบยืมคืนอุปกรณ์ ภาควิชาวิศวกรรมคอมพิวเตอร์</b></font></h1>
    <h3><font color="#ffffff"><b>คณะวิศวกรรมศาสตร์ กำแพงแสน มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</b></font></h3>
    </div>
    <br>  
</header>