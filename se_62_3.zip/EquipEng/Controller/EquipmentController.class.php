<?php
/**
 * Created by PhpStorm.
 * User: Diiar
 * Date: 24/1/2562
 * Time: 14:51
 */

class EquipmentController
{
    public function handleRequest(string $action="index", array $params) {
        switch ($action) {
            case "addEquip":
                $name = $params["POST"]["name"]??"";
                $idType = $params["POST"]["type"]??"";
                $status = "ว่าง";
                if ($name !== "" && $idType !== "") {
                    $this->$action($name, $idType,$status);
                }
                break;
            case "delete":
                $idEquip = $params["GET"]["id"]??"";
                $this->$action($idEquip);
                break;
            case "changeEq":
                $idEquip = $params["POST"]["id"]??"";
                $name = $params["POST"]["name"]??"";
                $idType = $params["POST"]["type"]??"";
                $status = $params["POST"]["stat"]??"";
                $this->$action($idEquip,$name, $idType,$status);
                break;
            case "add":
                $this->$action();
                break;
            case "edit":
                $this->$action();
                break;
            case "change":
                $this->$action();
                break;
            case "index":
                $this->index();
                break;
            default:
                break;

        }
    }
    private function change()
    {
        include Router::getSourcePath() . "Views/changeEquip.inc.php";
    }

    private function add()
    {
        include Router::getSourcePath() . "Views/addEquip.inc.php";
    }
    private function edit()
    {
        include Router::getSourcePath() . "Views/editEquip.inc.php";
    }

    private function delete(string $id)
    {
        $equip = Equipment::findById($id);
        if ($equip->delete()) {
            include Router::getSourcePath()."views/editEquip.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }

    private function addEquip(string $name,float $idType,string $status)
    {
        $equip = new Equipment();
        $equip->setName($name);
        $equip->setIdType($idType);
        $equip->setStatus($status);
        if ($equip->insert()) {
            include Router::getSourcePath()."views/editEquip.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }
    private function changeEq(string $idEquip,string $name,float $idType,string $status)
    {
        $equip = new Equipment();
        $equip->setIdEquipment($idEquip);
        $equip->setName($name);
        $equip->setIdType($idType);
        $equip->setStatus($status);
        if ($equip->update()) {
            include Router::getSourcePath()."views/editEquip.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }


    private function index() {

    }
}