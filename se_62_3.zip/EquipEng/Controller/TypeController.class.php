<?php
/**
 * Created by PhpStorm.
 * User: Diiar
 * Date: 24/1/2562
 * Time: 14:51
 */

class TypeController
{
    public function handleRequest(string $action="index", array $params) {
        switch ($action) {
            case "addType":
                $name = $params["POST"]["name"]??"";
                if ($name !== "") {
                    $this->$action($name);
                }
                break;
            case "delete":
                $idType = $params["GET"]["id"]??"";
                $this->$action($idType);
                break;
            case "changeTy":
                $idType = $params["POST"]["idtype"]??"";
                $name = $params["POST"]["name"]??"";
                $this->$action($name, $idType);
                break;
            case "edit":
                $this->$action();
                break;
            case "change":
                $this->$action();
                break;
            case "add":
                $this->$action();
                break;
            case "index":
                $this->index();
                break;
            default:
                break;

        }
    }

    private function add()
    {
        include Router::getSourcePath() . "Views/addType.inc.php";
    }private function change()
    {
    include Router::getSourcePath() . "Views/changeType.inc.php";
    }
    private function edit()
    {
        include Router::getSourcePath() . "Views/editType.inc.php";
    }

    private function addType(string $name)
    {
        $type = new Type();
        $type->setName($name);
        if ($type->insert()) {
            include Router::getSourcePath()."views/editType.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }
    private function delete(string $id)
    {
        $Type = Type::findById($id);
        if ($Type->delete()) {
            include Router::getSourcePath()."views/editType.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }
    private function changeTy(string $name,float $idType)
    {
        $type = new Type();
        $type->setIdType($idType);
        $type->setName($name);
        if ($type->update()) {
            include Router::getSourcePath()."views/editType.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }

    private function index() {

    }
}