<?php
/**
 * Created by PhpStorm.
 * User: Diiar
 * Date: 24/1/2562
 * Time: 14:51
 */

class BorrowController{
    public function handleRequest(string $action="index", array $params) {
        switch ($action) {
            case "borrowEquip":
                session_start();
                $idBorrower = $_SESSION['idUser'];
                $idEquip = $params["POST"]["idequip"]??"";
                $borrowDate = $params["POST"]["borrowdate"]??"";
                $returnDate = $params["POST"]["returndate"]??"";
                $appBy = $params["POST"]["appby"]??"";
                $this->$action($idBorrower,$idEquip,$borrowDate,$returnDate,$appBy);
                break;
            case "app":
                $idBorrowing = $params["GET"]["id"]??"";
                $this->$action($idBorrowing);
                break;
            case "borrow":
                $this->$action();
                break;
            case "news":
                $this->$action();
                break;
            case "edit":
                $this->$action();
                break;
            case "index":
                $this->index();
                break;
            default:
                break;

        }
    }

    private function borrow() {
        include Router::getSourcePath()."Views/borrow.inc.php";
    }
    private function news() {
        include Router::getSourcePath()."Views/history.inc.php";
    }
    private function edit() {
        include Router::getSourcePath()."Views/editBorrow.inc.php";
    }

    private function borrowEquip(string $idBorrower,string $idEquip,string $borrowDate,string $returnDate,string $appBy)
    {
        $borrow = new Borrow();
        $borrow->setIdBorrower($idBorrower);
        $borrow->setIdEquipment($idEquip);
        $borrow->setBorrowdate($borrowDate);
        $borrow->setReturndate($returnDate);
        $borrow->setAppby($appBy);
        if ($borrow->insert()) {
            include Router::getSourcePath()."views/menu.inc.php";
        } else {
            //header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }
    private function app($idBorrowing)
    {
        $borrow = Borrow::findBorrow($idBorrowing);
        $newbr = new Borrow();
        $newbr->setIdBorrowing($idBorrowing);
        $newbr->setIdBorrower($borrow->getIdBorrower());
        $newbr->setIdEquipment($borrow->getIdEquipment());
        $newbr->setBorrowdate($borrow->getBorrowdate());
        $newbr->setReturndate($borrow->getReturndate());
        $newbr->setAppby($borrow->getAppby());
        $newbr->setStatus("อนุมัติ");
        if ($newbr->update()) {
            include Router::getSourcePath()."views/menu.inc.php";
        } else {
            //header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }

    }




    private function index() {

    }
}