<?php
class MemberController {

/**
 * handleRequest จะทำการตรวจสอบ action และพารามิเตอร์ที่ส่งเข้ามาจาก Router
 * แล้วทำการเรียกใช้เมธอดที่เหมาะสมเพื่อประมวลผลแล้วส่งผลลัพธ์กลับ
 *
 * @param string $action ชื่อ action ที่ผู้ใช้ต้องการทำ
 * @param array $params พารามิเตอร์ที่ใช้เพื่อในการทำ action หนึ่งๆ
 */
public function handleRequest(string $action="index", array $params) {
    switch ($action) {
        case "login":
            $username = $params["POST"]["username"]??"";
            $pass = $params["POST"]["password"]??"";
            if ($username !== "" && $pass !== "") {
                $this->$action($username, $pass);
            }
            break;
        case "addNew":
            $name = $params["POST"]["name"];
            $surname = $params["POST"]["surname"];
            $username = $params["POST"]["username"];
            $password = $params["POST"]["password"];
            $role = $params["POST"]["role"];
            $idAdviser = $params["POST"]["idAdviser"];
            $this->$action($name,$surname,$username,$password,$role,$idAdviser);
            break;
        case "delete":
            $idUser = $params["GET"]["id"];
            $this->$action($idUser);
            break;
        case "signUp":
            $this->$action();
            break;
        case "change":
            $this->$action();
            break;
        case "changeMe":
            $iduser = $params["POST"]["id"];
            $name = $params["POST"]["name"];
            $surname = $params["POST"]["surname"];
            $username = $params["POST"]["username"];
            $password = $params["POST"]["password"];
            $role = $params["POST"]["role"];
            $idAdviser = $params["POST"]["idAdviser"];
            $this->$action($iduser,$name,$surname,$username,$password,$role,$idAdviser);
            break;
        case "profile":
            $this->$action();
            break;
        case "backhome":
            $this->$action();
            break;
        case "edit":
            $this->$action();
            break;
        case "index":
            $this->index();
            break;
        default:
            break;
    }
}

    private function signUp (){
        include Router::getSourcePath()."Views/regis.inc.php";
    }
    private function profile(){
        include Router::getSourcePath()."Views/member.inc.php";
    }
    private function backhome(){
        include Router::getSourcePath()."Views/menu.inc.php";
    }
    private function edit(){
        include Router::getSourcePath()."Views/editMember.inc.php";
    }
    private function change(){
        include Router::getSourcePath()."Views/changeMember.inc.php";
    }

    private function addNew ($name,$surname,$username,$password,$role,$idAdviser){
        $member = new Member();
        $member->setName($name);
        $member->setSurname($surname);
        $member->setUsername($username);
        $member->setPassword($password);
        $member->setRole($role);
        $member->setIdAdviser($idAdviser);
        if($member->insert()){
            header("Location: ".Router::getSourcePath()."index.php?msg=Registry Succeed");
        }
        else {
            header("Location: ".Router::getSourcePath()."index.php?msg=Registry Unsucceed");
        }

    }
    private function login(string $username, string $password) {
        if($username=="kasetsart"&&$password=="kukps"){
            include Router::getSourcePath()."Views/approve.inc.php";
        }
        else{
            $member = Member::findByAccount($username,$password) ;
        if ($member !== null){
            session_start();
            $_SESSION['member'] = $member;
            $_SESSION['name'] = $member->getName();
            $_SESSION['surname'] = $member->getSurname();
            $_SESSION['idUser'] = $member->getIdUser();
            $_SESSION['username'] = $member->getUsername();
            $_SESSION['password'] = $member->getPassword();
            $_SESSION['role'] = $member->getRole();
            $_SESSION['idAdviser'] = $member->getIdAdviser();
            include Router::getSourcePath()."Views/menu.inc.php";
        }
        else {
            header("Location: ".Router::getSourcePath()."index.php?msg=invalid username or password");
        }
        }
    }

    private function changeMe($iduser,$name,$surname,$username,$password,$role,$idAdviser)
    {
        $member = new Member();
        $member->setIdUser($iduser);
        $member->setName($name);
        $member->setSurname($surname);
        $member->setUsername($username);
        $member->setPassword($password);
        $member->setRole($role);
        $member->setIdAdviser($idAdviser);
        if ($member->update()) {
            include Router::getSourcePath()."views/editMember.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }
    }

    private function delete(string $id)
    {
        $equip = Member::findById($id);
        if ($equip->delete()) {
            include Router::getSourcePath()."views/editMember.inc.php";
        } else {
            header("Location: " . Router::getSourcePath() . "index.php?msg=Error");
        }
    }

    private function index() {
        include Router::getSourcePath()."Views/menu.inc.php";
    }
}