-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2020 at 06:21 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `equipmentsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrowing`
--

CREATE TABLE `borrowing` (
  `idBorrowing` int(11) NOT NULL,
  `idBorrower` int(11) NOT NULL,
  `idEquipment` int(11) NOT NULL,
  `borrowdate` date NOT NULL,
  `returndate` date NOT NULL,
  `status` enum('อนุมัติ','ไม่อนุมัติ','รออนุมัติ','') NOT NULL,
  `appby` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `borrowing`
--

INSERT INTO `borrowing` (`idBorrowing`, `idBorrower`, `idEquipment`, `borrowdate`, `returndate`, `status`, `appby`) VALUES
(171540278, 66331455, 965996206, '2020-03-25', '2020-03-28', 'รออนุมัติ', 0),
(270238746, 54941895, 965996209, '2020-03-25', '2020-05-29', 'รออนุมัติ', 0),
(282904859, 310539670, 442097413, '2020-03-26', '2020-03-29', 'อนุมัติ', 435727282),
(412591911, 310539670, 455899804, '2020-03-29', '2020-04-29', 'รออนุมัติ', 435727282),
(528691186, 196224883, 547865919, '2020-03-28', '2020-03-31', 'รออนุมัติ', 435727282),
(572492203, 310539670, 18041279, '2020-03-27', '2020-03-29', 'อนุมัติ', 435727282),
(830834395, 196224883, 965996210, '2020-03-27', '2020-04-30', 'รออนุมัติ', 435727282);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `idEquipment` int(11) NOT NULL,
  `name` text NOT NULL,
  `idType` int(11) NOT NULL,
  `status` enum('จองแล้ว','ว่าง','ชำรุด','ถูกยืมอยู่') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`idEquipment`, `name`, `idType`, `status`) VALUES
(334267386, 'บอร์ดทดลอง4', 1, 'ว่าง'),
(455899804, 'บอร์ดทดลอง2', 1, 'จองแล้ว'),
(547865919, 'Acer Aspire E15', 4, 'จองแล้ว'),
(682169306, 'บอร์ดทดลอง5', 1, 'ว่าง'),
(762488360, 'บอร์ดทดลอง3', 1, 'ว่าง'),
(965996206, 'บอร์ดทดลอง1', 1, 'จองแล้ว'),
(965996207, 'สายไฟมอนิเตอร์', 2, 'ว่าง'),
(965996208, 'ปลั๊กไฟ เต้าเสียบ6', 2, 'ว่าง'),
(965996209, 'Notebook Dell Inspiron 7472-W56795261RTHW10 (Gold)', 4, 'จองแล้ว'),
(965996210, 'Dell Notebook Dell Inspiron N3459-W5663104TH (Black)', 4, 'จองแล้ว'),
(965996211, 'DELL Notebook Inspiron 3567 W566955106WTHW10', 4, 'ว่าง'),
(965996212, 'Dell Notebook Inspiron 7472-W56795261RTHW10 (Gray)', 4, 'ชำรุด'),
(965996213, '\r\nDELL Notebook Inspiron 7472-W56795261RTHW10', 4, 'ว่าง'),
(965996214, 'สายLAN', 2, 'จองแล้ว'),
(965996215, 'สายLAN', 2, 'จองแล้ว');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `idType` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`idType`, `name`) VALUES
(1, 'บอร์ด'),
(2, 'สายไฟ'),
(3, 'พอยเตอร์'),
(4, 'โน้ตบุ๊ค'),
(5, 'กระดาน');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `name` text NOT NULL,
  `surname` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `role` enum('นิสิต','อาจารย์','เจ้าหน้าที่','') NOT NULL,
  `idAdviser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idUser`, `name`, `surname`, `username`, `password`, `role`, `idAdviser`) VALUES
(31535411, 'Will', 'Smith', 'Wll', '123456', 'อาจารย์', 0),
(66331455, 'เจ้าหน้าที่', 'เจ้าหน้าที่', 'admin', 'admin', 'เจ้าหน้าที่', 0),
(196224883, 'ศิรประภา', 'ตั้งจิรพาณิชย์', 'sira919', '9192154', 'นิสิต', 435727282),
(310539670, 'AA', 'AA', 'test1', '1234', 'นิสิต', 435727282),
(435727282, 'non', 'non', 'teacher1', '1234', 'อาจารย์', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD PRIMARY KEY (`idBorrowing`),
  ADD KEY `idBorrower` (`idBorrower`),
  ADD KEY `idEquipment` (`idEquipment`),
  ADD KEY `appby` (`appby`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`idEquipment`),
  ADD KEY `idType` (`idType`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`idType`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`),
  ADD KEY `idAdvisor` (`idAdviser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrowing`
--
ALTER TABLE `borrowing`
  MODIFY `idBorrowing` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=883335593;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `idEquipment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=965996216;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `idType` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=907851586;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
