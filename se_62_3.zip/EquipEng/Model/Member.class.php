<?php

class Member{
    private $idUser;
    private $name;
    private $surname;
    private $username;
    private $password;
    private $role;
    private $idAdviser;

    /**
     * @return mixed
     */
    public function getIdUser()
    {
        return $this->idUser;
    }

    /**
     * @param mixed $idUser
     */
    public function setIdUser($idUser): void
    {
        $this->idUser = $idUser;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getSurname()
    {
        return $this->surname;
    }

    /**
     * @param mixed $surname
     */
    public function setSurname($surname): void
    {
        $this->surname = $surname;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username): void
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password): void
    {
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * @param mixed $role
     */
    public function setRole($role): void
    {
        $this->role = $role;
    }

    /**
     * @return mixed
     */
    public function getIdAdviser()
    {
        return $this->idAdviser;
    }

    /**
     * @param mixed $idAdvisor
     */
    public function setIdAdviser($idAdviser): void
    {
        $this->idAdviser = $idAdviser;
    }



    
    private const TABLE = "user";

    public static function findRole(): array {
        $con = Db::getInstance();
        $query = "SELECT role FROM `user`";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }

    public static function findAll(): array {
        $con = Db::getInstance();
        $query = "SELECT * FROM `user`";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }

    public static function findById(int $idUser): ?Member {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE idUser = $idUser";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }

    public static function findByAccount(string $username,string $password){
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE username = '$username' AND password = '$password'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }

    public function insert() {
        $con = Db::getInstance();
        $values = "";
        $this->setIdUser(mt_rand(0, 1000000000));
        foreach ($this as $prop => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        //echo $query;
        $res = $con->exec($query);
        return $res;
    }

    public function update() {
        $query = "UPDATE ".self::TABLE." SET ";
        foreach ($this as $prop => $val) {
            $query .= " $prop='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE idUser = ".$this->getIdUser();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    public function delete() {
        $query = " Delete FROM ".self::TABLE;
        $query .= " WHERE idUser = ".$this->getIdUser();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
}