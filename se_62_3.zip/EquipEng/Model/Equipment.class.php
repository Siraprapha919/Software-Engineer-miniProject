<?php

class Equipment{
    private $idEquipment;
    private $name;
    private $idType;
    private $status;

    /**
     * @return mixed
     */
    public function getIdEquipment()
    {
        return $this->idEquipment;
    }

    /**
     * @param mixed $idEquipment
     */
    public function setIdEquipment($idEquipment): void
    {
        $this->idEquipment = $idEquipment;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getIdType()
    {
        return $this->idType;
    }

    /**
     * @param mixed $idType
     */
    public function setIdType($idType): void
    {
        $this->idType = $idType;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status): void
    {
        $this->status = $status;
    }

    private const TABLE = "equipment";


    public static function findByIdOb(string $id): ?Equipment {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE idEquipment = '$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Equipment");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }

    public static function findByType(string $Type): array {
        $con = Db::getInstance();
        $query = "SELECT idEquipment,name,status FROM `equipment` where idType = '$Type'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }

    public static function findAllEquip(): array {
        $con = Db::getInstance();
        $query = "SELECT idEquipment,name,status FROM `equipment`";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }


    public static function findFree(): array {
        $con = Db::getInstance();
        $query = "SELECT idEquipment FROM `equipment` where status = 'ว่าง'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }

    public static function findById(string $id){
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE idEquipment = '$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Equipment");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }

    public function insert() {
        $con = Db::getInstance();
        $values = "";
        $this->setIdEquipment(mt_rand(0, 1000000000));
        foreach ($this as $prop => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        //echo $query;
        $res = $con->exec($query);
        return $res;
    }

    public function update() {
        $query = "UPDATE ".self::TABLE." SET ";
        foreach ($this as $prop => $val) {
            $query .= " $prop='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE idEquipment = ".$this->getIdEquipment();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function delete() {
        $query = " Delete FROM ".self::TABLE;
        $query .= " WHERE idEquipment = ".$this->getIdEquipment();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
}