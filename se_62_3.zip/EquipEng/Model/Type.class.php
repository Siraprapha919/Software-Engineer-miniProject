<?php

class Type{
    private $idType;
    private $name;

    /**
     * @return mixed
     */
    public function getIdType()
    {
        return $this->idType;
    }

    /**
     * @param mixed $idType
     */
    public function setIdType($idType): void
    {
        $this->idType = $idType;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }


    private const TABLE = "type";


    public static function findAll(): array {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Type");
        $stmt->execute();
        $memberList  = array();
        while ($mem = $stmt->fetch())
        {
            $memberList[$mem->getIdType()] = $mem;
        }
        return $memberList;
    }

    public static function findAllType(): array {
        $con = Db::getInstance();
        $query = "SELECT idType,name FROM `type`";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }
    public static function findById(string $id){
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE idType = '$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Type");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }


    public function insert() {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $prop => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        //echo $query;
        $res = $con->exec($query);
        return $res;
    }

    public function update() {
        $query = "UPDATE ".self::TABLE." SET ";
        foreach ($this as $prop => $val) {
            $query .= " $prop='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE idType = ".$this->getIdType();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
}