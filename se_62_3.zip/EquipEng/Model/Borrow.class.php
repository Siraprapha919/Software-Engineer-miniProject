<?php

class Borrow{
    private $idBorrowing;
    private $idBorrower;
    private $idEquipment;
    private $borrowdate;
    private $returndate;
    private $status;
    private $appby;

    /**
     * @return mixed
     */
    public function getIdBorrowing()
    {
        return $this->idBorrowing;
    }

    /**
     * @param mixed $idBorrowing
     */
    public function setIdBorrowing($idBorrowing): void
    {
        $this->idBorrowing = $idBorrowing;
    }

    /**
     * @return mixed
     */
    public function getIdBorrower()
    {
        return $this->idBorrower;
    }

    /**
     * @param mixed $idBorrower
     */
    public function setIdBorrower($idBorrower): void
    {
        $this->idBorrower = $idBorrower;
    }

    /**
     * @return mixed
     */
    public function getIdEquipment()
    {
        return $this->idEquipment;
    }

    /**
     * @param mixed $idEquipment
     */
    public function setIdEquipment($idEquipment): void
    {
        $this->idEquipment = $idEquipment;
    }

    /**
     * @return mixed
     */
    public function getBorrowdate()
    {
        return $this->borrowdate;
    }

    /**
     * @param mixed $borrowdate
     */
    public function setBorrowdate($borrowdate): void
    {
        $this->borrowdate = $borrowdate;
    }

    /**
     * @return mixed
     */
    public function getReturndate()
    {
        return $this->returndate;
    }

    /**
     * @param mixed $returndate
     */
    public function setReturndate($returndate): void
    {
        $this->returndate = $returndate;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status): void
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getAppby()
    {
        return $this->appby;
    }

    /**
     * @param mixed $appby
     */
    public function setAppby($appby): void
    {
        $this->appby = $appby;
    }

    private const TABLE = "borrowing";


    public static function findAll(): array {
        $con = Db::getInstance();
        $query = "SELECT * FROM `borrowing`";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }
    public static function findBorrow(int $id): ?Borrow {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE idBorrowing = $id";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Borrow");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }

    public static function findById(string $id): array {
        $con = Db::getInstance();
        $query = "SELECT * FROM `borrowing` where appby = '$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $reList  = array();
        while ($re = $stmt->fetch())
        {
            $reList[] = $re;
        }
        return $reList;
    }

    public function insert() {
        $con = Db::getInstance();
        $values = "";
        $this->setIdBorrowing(mt_rand(0, 1000000000));
        $this->setStatus("รออนุมัติ");
        $equip = Equipment::findById($this->getIdEquipment());
        $equip->setStatus("จองแล้ว");
        $equip->update();
        foreach ($this as $prop => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        //echo $query;
        $res = $con->exec($query);
        return $res;
    }

    public function update() {
        $query = "UPDATE ".self::TABLE." SET ";
        foreach ($this as $prop => $val) {
            $query .= " $prop='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE idBorrowing = ".$this->getIdBorrowing();
        $con = Db::getInstance();
        $equip = Equipment::findByIdOb($this->getIdEquipment());
        if($this->getStatus() == "ไม่อนุมัติ") {
            $equip->setStatus("ว่าง");
        }else if($this->getStatus() == "อนุมัติ") {
            $equip->setStatus("ถูกยืมอยู่");
        }
        $equip->update();
        $res = $con->exec($query);
        return $res;
    }
}